
public class Telefonbucheintrag {
	public String vname;
	public String nname;
	public String telnr;
	public Telefonbucheintrag(String vname, String nname, String telnr){
		this.vname = vname;
		this.nname = nname;
		this.telnr = telnr;
	}
	public Telefonbucheintrag(){
		vname="";
		nname="";
		telnr="";
	}
}
