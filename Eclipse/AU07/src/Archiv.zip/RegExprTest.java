
public class RegExprTest {
	public static void main(String[] args){
		new RegExprController();
	}
}
