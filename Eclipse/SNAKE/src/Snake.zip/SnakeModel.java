import java.awt.List;
import java.awt.Point;
import java.util.LinkedList;


public class SnakeModel {
	LinkedList<Point> schlange;
	int schrittweite;
	public SnakeModel(){
		Point a = new Point(10,10);
		schlange = new LinkedList<Point>();
		schlange.add(a);
		schrittweite = 10;
	}
	public void rauf(){
		Point kopf = new Point(schlange.getLast().x, schlange.getLast().y - schrittweite);
		schlange.add(kopf);
	}
	public void runter(){
		Point kopf = new Point(schlange.getLast().x, schlange.getLast().y + schrittweite);
		schlange.add(kopf);
	}
	public void links(){
		Point kopf = new Point(schlange.getLast().x - schrittweite, schlange.getLast().y);
		schlange.add(kopf);
	}
	public void rechts(){
		Point kopf = new Point(schlange.getLast().x + schrittweite, schlange.getLast().y);
		schlange.add(kopf);
	}
}
