import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class SnakeController implements ActionListener {
	SnakeModel m;
	SnakeView v;
	public SnakeController(){
		this.m = new SnakeModel();
		this.v = new SnakeView(this.m, this);
	}
	public void actionPerformed(ActionEvent e){
		if(v.isButtonRechts(e)){
			m.rechts();
		}
		if(v.isButtonLinks(e)){
			m.links();
		}
		if(v.isButtonRauf(e)){
			m.rauf();
		}
		if(v.isButtonRunter(e)){
			m.runter();
		}
		
		
		v.refresh();
	}
}
