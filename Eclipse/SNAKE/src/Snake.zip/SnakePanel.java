import java.awt.*;
import java.util.*;

import javax.swing.JPanel;


public class SnakePanel extends JPanel {
	SnakeModel m;
	
	public SnakePanel(SnakeModel m){
		this.m = m;
		
		this.setSize(new Dimension (400,200));
	}
	@SuppressWarnings("unchecked")
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		int x = m.schlange.getLast().x;
		int y = m.schlange.getLast().y;
		g.drawOval(x,y,20,20);
		Iterator <Point> i = m.schlange.iterator();
		boolean anfang = true;
		while(i.hasNext()){
			Point p1 = i.next();
			if(!anfang){
				Point p2 = i.next();
				g.drawLine(p1.x, p1.y,p2.x, p2.y);
			}
			anfang = false;
			this.repaint();
		}
	}
}
