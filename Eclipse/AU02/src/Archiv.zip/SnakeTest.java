
public class SnakeTest {
	public static void main (String [] args) {
		new SnakeController();
	}
}