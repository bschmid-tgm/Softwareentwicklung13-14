import java.awt.*;
import java.util.*;
import java.util.Random;

import javax.swing.JPanel;


public class SnakePanel extends JPanel {
	SnakeModel m;
	Point a;
	public SnakePanel(SnakeModel m){
		this.m = m;
		a = m.futter();
		this.setSize(new Dimension (600,400));
	}
	@SuppressWarnings("unchecked")
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		g.fillOval(a.x,a.y, 20, 20);
		if(a.x==m.schlange.getLast().x&&a.y==m.schlange.getLast().y){
			a = m.futter();
			m.schlange.addLast(m.schlange.getLast());
		}
		int x = m.schlange.getLast().x;
		int y = m.schlange.getLast().y;
		g.setColor(Color.GREEN);
		g.fillRect(x,y,20,20);
		Iterator <Point> i = m.schlange.iterator();
		boolean anfang = true;
		while(i.hasNext()){
			Point p1 = i.next();
				try{
					Random rand = new Random();
					float rot = rand.nextFloat();
					float gelb = rand.nextFloat();
					float blau = rand.nextFloat();
					Color randomColor = new Color(rot, gelb, blau);
					g.setColor(Color.GREEN);
					g.fillRect(p1.x,p1.y,20,20);
				}catch(NoSuchElementException e){}
			anfang = false;
			this.repaint();
		}
	}
}
